# AutoSignMachine

> Due to a third-party risk dispute, this script stopped sharing
> 由于第三方风险争议，此脚本停止分享